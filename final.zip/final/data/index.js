const comments = require("./comments");
const tabs = require("./tabs");
const users = require("./users");

module.exports = {
    comments: comments,
    tabs: tabs,
    users: users,
}